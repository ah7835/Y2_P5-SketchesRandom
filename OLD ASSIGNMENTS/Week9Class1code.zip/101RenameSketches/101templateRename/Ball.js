/**
 * Aziel Shaw, 10/21/2019
 * Ball: Creates a ball that will bound around the 
 *      canvas
 */
class Ball {
    /**
     * Constructs the ball given a color
     * generates random fields inside
     * @param {The color of the ball} ballColor 
     */
    constructor(ballColor) {
        this.x = random(0, width);
        this.y = random(0, height);
        this.xSpeed = random(0, 3);
        this.ySpeed = random(0, 3);
        this.color = ballColor
        this.size = random(10,60)
    }

    /**
     * Draws the ball
     */
    draw() {
        fill(this.color)
        circle(this.x, this.y, this.size);
    }

    /**
     * Moves the ball
     */
    move() {
        // Do we need to change xSpeed?
        if ((this.x > width - (this.size/2)) || (this.x < (this.size/2))){ 
            this.xSpeed = this.xSpeed * -1; //reverse
        }
        // Do we need to change ySpeed?
        if ((this.y > height - (this.size/2)) || (this.y < (this.size/2))){ 
            this.ySpeed = this.ySpeed * -1; //reverse
        }

        // move the ball
        this.x = this.x + this.xSpeed;
        this.y = this.y + this.ySpeed;
    }
}