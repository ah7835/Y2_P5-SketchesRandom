class Car {
    constructor(color, name) {
        this.xPos = width/2;;
        this.yPos = random(height);
        this.speed = 0;
        this.carColor = color;
        this.carName = name;
        this.carCondition = "New"
        console.log("Created car with name: " + name)
    }

    start() { // method!
        this.speed = random(-2, 2);
        console.log("Car started with speed: " + this.speed)
    }

    display() { // method!
        fill(this.carColor);
        rect(this.xPos, this.yPos, 20, 10);
    }

    move(scale) { // method!
        this.xPos += this.speed * scale;
        // Wrap x around boundaries
        if (this.xPos < -20) {
            this.xPos = width;
        } else if (this.xPos > width) {
            this.xPos = -20;
        }
    }
} //end 