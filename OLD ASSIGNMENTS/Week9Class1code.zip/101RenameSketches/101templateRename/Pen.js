class Pen {
    constructor() {
       this.penHeight = 15;
       this.penThickness = 3;
       this.inkColor = "black";
       this.clickedOn = false;
    }
 }
 