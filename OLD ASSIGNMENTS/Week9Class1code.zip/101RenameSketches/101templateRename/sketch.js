/**
 * IDEAS: if mouse touches ball, stop balls
 */
let ball1;
let ball2;
let ball3;
let car1;
let car2;

function setup() {
  createCanvas(400, 600);
  background("gray");
  ball1 = new Ball("white");
  ball2 = new Ball("red");
  ball3 = new Ball("Blue");
  car1 = new Car("purple", "Honda");
  car2 = new Car("Black", "Skoda");

  // start the cars
  car1.start();
  car2.start();
}
function draw() {
  background("gray"); 
  
  // draw the ball
  ball1.draw();
  ball2.draw();
  ball3.draw();
  // draw the cars
  car1.display();
  car2.display();

  // move the ball
  ball1.move();
  ball2.move();
  ball3.move();
  // move the cars
  car1.move(1);
  car2.move(0.25);
}





// let car1;
// let car2;

// function setup() {
//   createCanvas(500,500)
//   frameRate(10);
//   car1 = new Car(250,250,"purple", "Honda Civic");
//   car2 = new Car(100,100,"black",  "Chevy Camero")
  
//   background("Grey");
//   // Draw car 1
//   fill(car1.carColor);
//   rect(car1.xPos, car1.yPos, 50,50);
//   // Draw car 2
//   fill(car2.carColor);
//   rect(car2.xPos, car2.yPos, 20,20);
// }

// function draw() {
// }
